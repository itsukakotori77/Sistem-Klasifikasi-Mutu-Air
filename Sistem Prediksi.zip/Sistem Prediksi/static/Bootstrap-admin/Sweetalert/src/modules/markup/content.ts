import CLASS_NAMES from '../class-list';

const { CONTENT } = CLASS_NAMES;

export const contentMarkup: string = `
  <div class="${CONTENT}">

  </div>
`;

